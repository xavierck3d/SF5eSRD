# SF5eSRD
A little private project where I replace all the fantasy stuff in the Dungeons and Dragons 5th edition SRD with sci-fi stuff. 

Based on https://5thsrd.org/
